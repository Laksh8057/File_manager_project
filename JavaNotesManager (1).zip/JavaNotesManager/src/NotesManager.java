import java.io.*;
import java.util.*;

public class NotesManager {
    private static final String NOTES_DIR = "notes";

    public static void main(String[] args) {
        File dir = new File(NOTES_DIR);
        if (!dir.exists()) dir.mkdir();

        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== Java Notes Manager =====");
            System.out.println("1. Create Note");
            System.out.println("2. View Notes");
            System.out.println("3. Edit Note");
            System.out.println("4. Delete Note");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            choice = Integer.parseInt(sc.nextLine());

            switch (choice) {
                case 1: createNote(sc); break;
                case 2: viewNotes(sc); break;
                case 3: editNote(sc); break;
                case 4: deleteNote(sc); break;
                case 5: System.out.println("Exiting..."); break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 5);
        sc.close();
    }

    private static void createNote(Scanner sc) {
        System.out.print("Enter note title: ");
        String title = sc.nextLine().trim();
        File noteFile = new File(NOTES_DIR + "/" + title + ".txt");

        if (noteFile.exists()) {
            System.out.println("Note already exists.");
            return;
        }

        System.out.println("Enter note content (end with a blank line):");
        StringBuilder content = new StringBuilder();
        while (true) {
            String line = sc.nextLine();
            if (line.isEmpty()) break;
            content.append(line).append("\n");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(noteFile))) {
            writer.write(content.toString());
            System.out.println("Note saved.");
        } catch (IOException e) {
            System.out.println("Error saving note: " + e.getMessage());
        }
    }

    private static void viewNotes(Scanner sc) {
        File dir = new File(NOTES_DIR);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".txt"));

        if (files == null || files.length == 0) {
            System.out.println("No notes found.");
            return;
        }

        System.out.println("Available notes:");
        for (int i = 0; i < files.length; i++) {
            System.out.println((i + 1) + ". " + files[i].getName().replace(".txt", ""));
        }

        System.out.print("Enter note number to view: ");
        int num = Integer.parseInt(sc.nextLine());
        if (num < 1 || num > files.length) {
            System.out.println("Invalid choice.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(files[num - 1]))) {
            System.out.println("\n----- " + files[num - 1].getName() + " -----");
            String line;
            while ((line = reader.readLine()) != null)
                System.out.println(line);
        } catch (IOException e) {
            System.out.println("Error reading note.");
        }
    }

    private static void editNote(Scanner sc) {
        File dir = new File(NOTES_DIR);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".txt"));

        if (files == null || files.length == 0) {
            System.out.println("No notes found.");
            return;
        }

        System.out.println("Available notes:");
        for (int i = 0; i < files.length; i++) {
            System.out.println((i + 1) + ". " + files[i].getName().replace(".txt", ""));
        }

        System.out.print("Enter note number to edit: ");
        int num = Integer.parseInt(sc.nextLine());
        if (num < 1 || num > files.length) {
            System.out.println("Invalid choice.");
            return;
        }

        File selectedFile = files[num - 1];
        System.out.println("Enter new content (end with a blank line):");
        StringBuilder content = new StringBuilder();
        while (true) {
            String line = sc.nextLine();
            if (line.isEmpty()) break;
            content.append(line).append("\n");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(selectedFile))) {
            writer.write(content.toString());
            System.out.println("Note updated.");
        } catch (IOException e) {
            System.out.println("Error updating note.");
        }
    }

    private static void deleteNote(Scanner sc) {
        File dir = new File(NOTES_DIR);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".txt"));

        if (files == null || files.length == 0) {
            System.out.println("No notes to delete.");
            return;
        }

        System.out.println("Available notes:");
        for (int i = 0; i < files.length; i++) {
            System.out.println((i + 1) + ". " + files[i].getName().replace(".txt", ""));
        }

        System.out.print("Enter note number to delete: ");
        int num = Integer.parseInt(sc.nextLine());
        if (num < 1 || num > files.length) {
            System.out.println("Invalid choice.");
            return;
        }

        if (files[num - 1].delete()) {
            System.out.println("Note deleted.");
        } else {
            System.out.println("Failed to delete note.");
        }
    }
}
